import { useEffect, useState } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Header } from "./components/marketplace/Header";
import { CategoryFilter } from "./components/marketplace/CategoryFilter";
import { ItemGrid } from "./components/marketplace/ItemGrid";
import { useMarketplace, Item, User } from "./lib/stores/useMarketplace";
import "@fontsource/inter";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});

// Sample data for demonstration
const sampleUsers: User[] = [
  {
    id: 1,
    username: "ahmed_salem",
    email: "ahmed@example.com",
    fullName: "أحمد سالم",
    phone: "+966501234567",
    location: "الرياض",
    createdAt: new Date("2024-01-15")
  },
  {
    id: 2,
    username: "fatima_ali",
    email: "fatima@example.com",
    fullName: "فاطمة علي",
    phone: "+966507654321",
    location: "جدة",
    createdAt: new Date("2024-02-10")
  },
  {
    id: 3,
    username: "omar_hassan",
    email: "omar@example.com",
    fullName: "عمر حسن",
    phone: "+966509876543",
    location: "الدمام",
    createdAt: new Date("2024-01-20")
  }
];

const sampleItems: Item[] = [
  {
    id: "1",
    title: "آيفون 13 مستعمل بحالة ممتازة",
    description: "آيفون 13 باللون الأزرق، 128 جيجا، مستعمل لمدة 6 أشهر فقط، بحالة ممتازة مع جميع الملحقات الأصلية",
    price: 2800,
    isFree: false,
    category: "electronics",
    condition: "excellent",
    images: ["https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=400"],
    sellerId: 1,
    seller: sampleUsers[0],
    location: "الرياض - حي النرجس",
    status: "active",
    createdAt: new Date("2024-12-10"),
    updatedAt: new Date("2024-12-10"),
    views: 45
  },
  {
    id: "2",
    title: "أريكة جلدية فاخرة - 3 مقاعد",
    description: "أريكة جلدية أصلية باللون البني، مريحة جداً ونظيفة، سبب البيع الانتقال لمنزل جديد",
    price: 1200,
    isFree: false,
    category: "furniture",
    condition: "good",
    images: ["https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=400"],
    sellerId: 2,
    seller: sampleUsers[1],
    location: "جدة - حي الصفا",
    status: "active",
    createdAt: new Date("2024-12-09"),
    updatedAt: new Date("2024-12-09"),
    views: 32
  },
  {
    id: "3",
    title: "لابتوب Dell للبرمجة والدراسة",
    description: "لابتوب Dell Inspiron 15، معالج i5، ذاكرة 8 جيجا، قرص صلب 512 SSD، مناسب للطلاب والمبرمجين",
    price: 1800,
    isFree: false,
    category: "electronics",
    condition: "good",
    images: ["https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400"],
    sellerId: 3,
    seller: sampleUsers[2],
    location: "الدمام - الشاطئ",
    status: "active",
    createdAt: new Date("2024-12-08"),
    updatedAt: new Date("2024-12-08"),
    views: 67
  },
  {
    id: "4",
    title: "كتب جامعية - مجاناً",
    description: "مجموعة كتب جامعية لتخصص إدارة الأعمال، حالة جيدة، مجانية لمن يريدها",
    price: 0,
    isFree: true,
    category: "books",
    condition: "fair",
    images: ["https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400"],
    sellerId: 1,
    seller: sampleUsers[0],
    location: "الرياض - الملز",
    status: "active",
    createdAt: new Date("2024-12-07"),
    updatedAt: new Date("2024-12-07"),
    views: 23
  },
  {
    id: "5",
    title: "طاولة طعام خشبية مع 6 كراسي",
    description: "طاولة طعام خشبية فاخرة مع 6 كراسي مبطنة، حالة ممتازة، مناسبة للعائلات الكبيرة",
    price: 2200,
    isFree: false,
    category: "furniture",
    condition: "excellent",
    images: ["https://images.unsplash.com/photo-1449247709967-d4461a6a6103?w=400"],
    sellerId: 2,
    seller: sampleUsers[1],
    location: "جدة - الروضة",
    status: "active",
    createdAt: new Date("2024-12-06"),
    updatedAt: new Date("2024-12-06"),
    views: 89
  },
  {
    id: "6",
    title: "دراجة هوائية للكبار",
    description: "دراجة هوائية ممتازة، استعملت قليلاً، مناسبة للرياضة والتنقل، مع جميع الملحقات",
    price: 450,
    isFree: false,
    category: "sports",
    condition: "good",
    images: ["https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400"],
    sellerId: 3,
    seller: sampleUsers[2],
    location: "الدمام - الخبر",
    status: "active",
    createdAt: new Date("2024-12-05"),
    updatedAt: new Date("2024-12-05"),
    views: 34
  }
];

function MarketplaceContent() {
  const { setItems, setCurrentUser } = useMarketplace();
  const [selectedItem, setSelectedItem] = useState<Item | null>(null);

  useEffect(() => {
    // Load sample data
    setItems(sampleItems);
    setCurrentUser(sampleUsers[0]); // Set current user for demo
  }, [setItems, setCurrentUser]);

  const handleItemClick = (item: Item) => {
    console.log('Selected item:', item);
    setSelectedItem(item);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-100">
      <Header />
      
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-gradient-to-r from-emerald-600 via-green-600 to-teal-600">
        <div className="absolute inset-0 bg-black/10" />
        <div className="absolute inset-0 bg-[url('/pattern.svg')] opacity-10" />
        <div className="relative container mx-auto px-6 py-12">
          <div className="text-center text-white">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              اكتشف كنوز مخفية في سوق خردة
            </h2>
            <p className="text-lg md:text-xl text-green-100 mb-8 max-w-2xl mx-auto">
              بيع واشتر كل ما تحتاجه من الأشياء المستعملة بأفضل الأسعار
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <div className="bg-white/20 backdrop-blur rounded-full px-6 py-3 border border-white/30">
                <span className="text-white font-medium">📱 إلكترونيات</span>
              </div>
              <div className="bg-white/20 backdrop-blur rounded-full px-6 py-3 border border-white/30">
                <span className="text-white font-medium">🪑 أثاث</span>
              </div>
              <div className="bg-white/20 backdrop-blur rounded-full px-6 py-3 border border-white/30">
                <span className="text-white font-medium">👕 ملابس</span>
              </div>
              <div className="bg-white/20 backdrop-blur rounded-full px-6 py-3 border border-white/30">
                <span className="text-white font-medium">📚 كتب</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="container mx-auto px-6 py-8">
        <div className="flex gap-8">
          {/* Sidebar */}
          <div className="hidden lg:block w-80 flex-shrink-0">
            <CategoryFilter />
          </div>
          
          {/* Main Content */}
          <div className="flex-1">
            <ItemGrid onItemClick={handleItemClick} />
          </div>
        </div>
      </div>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <MarketplaceContent />
    </QueryClientProvider>
  );
}

export default App;
