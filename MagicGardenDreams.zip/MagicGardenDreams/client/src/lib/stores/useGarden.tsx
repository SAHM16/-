import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";
import { PlacedPlant, GardenState, PLANT_TYPES } from "../gardenTypes";

interface GardenStore extends GardenState {
  selectedPlantType: string | null;
  isDragging: boolean;
  hoveredPosition: [number, number, number] | null;
  
  // Actions
  setSelectedPlantType: (plantTypeId: string | null) => void;
  addPlant: (position: [number, number, number]) => void;
  removePlant: (plantId: string) => void;
  updatePlant: (plantId: string, updates: Partial<PlacedPlant>) => void;
  setDragging: (isDragging: boolean) => void;
  setHoveredPosition: (position: [number, number, number] | null) => void;
  growPlant: (plantId: string) => void;
  saveGarden: () => void;
  loadGarden: () => void;
  clearGarden: () => void;
  setGardenName: (name: string) => void;
}

const generateId = () => Math.random().toString(36).substring(2) + Date.now().toString(36);

export const useGarden = create<GardenStore>()(
  subscribeWithSelector((set, get) => ({
    plants: [],
    decorations: [],
    lastSaved: null,
    gardenName: "My Magical Garden",
    selectedPlantType: null,
    isDragging: false,
    hoveredPosition: null,

    setSelectedPlantType: (plantTypeId) => {
      set({ selectedPlantType: plantTypeId });
    },

    addPlant: (position) => {
      const { selectedPlantType } = get();
      if (!selectedPlantType) return;

      const plantType = PLANT_TYPES.find(p => p.id === selectedPlantType);
      if (!plantType) return;

      const newPlant: PlacedPlant = {
        id: generateId(),
        plantType,
        position,
        rotation: Math.random() * Math.PI * 2,
        scale: 0.8 + Math.random() * 0.4, // Random scale between 0.8-1.2
        growthStage: 0.1, // Start small and grow
        isGlowing: plantType.magical
      };

      set(state => ({
        plants: [...state.plants, newPlant]
      }));

      // Auto-grow the plant
      setTimeout(() => {
        get().growPlant(newPlant.id);
      }, 100);
    },

    removePlant: (plantId) => {
      set(state => ({
        plants: state.plants.filter(p => p.id !== plantId)
      }));
    },

    updatePlant: (plantId, updates) => {
      set(state => ({
        plants: state.plants.map(p => 
          p.id === plantId ? { ...p, ...updates } : p
        )
      }));
    },

    setDragging: (isDragging) => {
      set({ isDragging });
    },

    setHoveredPosition: (position) => {
      set({ hoveredPosition: position });
    },

    growPlant: (plantId) => {
      set(state => ({
        plants: state.plants.map(p => 
          p.id === plantId 
            ? { ...p, growthStage: Math.min(1, p.growthStage + 0.1) }
            : p
        )
      }));
    },

    saveGarden: () => {
      const state = get();
      const gardenData = {
        plants: state.plants,
        decorations: state.decorations,
        gardenName: state.gardenName,
        lastSaved: new Date()
      };
      
      localStorage.setItem('magical-garden-save', JSON.stringify(gardenData));
      set({ lastSaved: new Date() });
      console.log('Garden saved successfully!');
    },

    loadGarden: () => {
      try {
        const saved = localStorage.getItem('magical-garden-save');
        if (saved) {
          const gardenData = JSON.parse(saved);
          set({
            plants: gardenData.plants || [],
            decorations: gardenData.decorations || [],
            gardenName: gardenData.gardenName || "My Magical Garden",
            lastSaved: gardenData.lastSaved ? new Date(gardenData.lastSaved) : null
          });
          console.log('Garden loaded successfully!');
        }
      } catch (error) {
        console.error('Failed to load garden:', error);
      }
    },

    clearGarden: () => {
      set({
        plants: [],
        decorations: [],
        selectedPlantType: null
      });
    },

    setGardenName: (name) => {
      set({ gardenName: name });
    }
  }))
);
