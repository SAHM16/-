import { create } from "zustand";
// Define types locally
export interface User {
  id: number;
  username: string;
  email: string;
  fullName: string;
  phone?: string;
  location?: string;
  avatar?: string;
  createdAt: Date;
}

export interface Category {
  id: string;
  name: string;
  nameAr: string;
  icon: string;
}

export interface Item {
  id: string;
  title: string;
  description: string;
  price: number;
  isFree: boolean;
  category: string;
  condition: 'excellent' | 'good' | 'fair' | 'poor';
  images: string[];
  sellerId: number;
  seller: User;
  location: string;
  status: 'active' | 'sold' | 'reserved';
  createdAt: Date;
  updatedAt: Date;
  views: number;
}

export const CATEGORIES: Category[] = [
  { id: 'electronics', name: 'Electronics', nameAr: 'إلكترونيات', icon: 'Smartphone' },
  { id: 'furniture', name: 'Furniture', nameAr: 'أثاث', icon: 'Sofa' },
  { id: 'clothing', name: 'Clothing', nameAr: 'ملابس', icon: 'Shirt' },
  { id: 'books', name: 'Books', nameAr: 'كتب', icon: 'Book' },
  { id: 'tools', name: 'Tools', nameAr: 'أدوات', icon: 'Wrench' },
  { id: 'sports', name: 'Sports & Outdoors', nameAr: 'رياضة وخارجية', icon: 'Bike' },
  { id: 'home', name: 'Home & Garden', nameAr: 'بيت وحديقة', icon: 'Home' },
  { id: 'vehicles', name: 'Vehicles', nameAr: 'مركبات', icon: 'Car' },
  { id: 'other', name: 'Other', nameAr: 'أخرى', icon: 'Package' }
];

interface MarketplaceState {
  items: Item[];
  categories: Category[];
  selectedCategory: string | null;
  searchQuery: string;
  currentUser: User | null;
  isLoading: boolean;
  favorites: string[];
  
  // Actions
  setItems: (items: Item[]) => void;
  setSelectedCategory: (categoryId: string | null) => void;
  setSearchQuery: (query: string) => void;
  setCurrentUser: (user: User | null) => void;
  setLoading: (loading: boolean) => void;
  addToFavorites: (itemId: string) => void;
  removeFromFavorites: (itemId: string) => void;
  addItem: (item: Omit<Item, 'id' | 'createdAt' | 'updatedAt' | 'views'>) => void;
  updateItem: (itemId: string, updates: Partial<Item>) => void;
  deleteItem: (itemId: string) => void;
}

const generateId = () => Math.random().toString(36).substring(2) + Date.now().toString(36);

export const useMarketplace = create<MarketplaceState>((set, get) => ({
  items: [],
  categories: CATEGORIES,
  selectedCategory: null,
  searchQuery: '',
  currentUser: null,
  isLoading: false,
  favorites: JSON.parse(localStorage.getItem('khurda-favorites') || '[]'),

  setItems: (items) => set({ items }),
  
  setSelectedCategory: (categoryId) => set({ selectedCategory: categoryId }),
  
  setSearchQuery: (query) => set({ searchQuery: query }),
  
  setCurrentUser: (user) => set({ currentUser: user }),
  
  setLoading: (loading) => set({ isLoading: loading }),
  
  addToFavorites: (itemId) => {
    const favorites = [...get().favorites, itemId];
    localStorage.setItem('khurda-favorites', JSON.stringify(favorites));
    set({ favorites });
  },
  
  removeFromFavorites: (itemId) => {
    const favorites = get().favorites.filter(id => id !== itemId);
    localStorage.setItem('khurda-favorites', JSON.stringify(favorites));
    set({ favorites });
  },
  
  addItem: (itemData) => {
    const newItem: Item = {
      ...itemData,
      id: generateId(),
      createdAt: new Date(),
      updatedAt: new Date(),
      views: 0,
      status: 'active'
    };
    
    set(state => ({
      items: [newItem, ...state.items]
    }));
  },
  
  updateItem: (itemId, updates) => {
    set(state => ({
      items: state.items.map(item => 
        item.id === itemId 
          ? { ...item, ...updates, updatedAt: new Date() }
          : item
      )
    }));
  },
  
  deleteItem: (itemId) => {
    set(state => ({
      items: state.items.filter(item => item.id !== itemId)
    }));
  }
}));