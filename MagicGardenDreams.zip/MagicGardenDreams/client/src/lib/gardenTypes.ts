export interface PlantType {
  id: string;
  name: string;
  category: 'flower' | 'tree' | 'shrub' | 'magical';
  color: string;
  glowColor?: string;
  size: 'small' | 'medium' | 'large';
  magical: boolean;
  description: string;
}

export interface PlacedPlant {
  id: string;
  plantType: PlantType;
  position: [number, number, number];
  rotation: number;
  scale: number;
  growthStage: number; // 0-1
  isGlowing: boolean;
}

export interface GardenState {
  plants: PlacedPlant[];
  decorations: any[];
  lastSaved: Date | null;
  gardenName: string;
}

export const PLANT_TYPES: PlantType[] = [
  {
    id: 'rose',
    name: 'Magical Rose',
    category: 'flower',
    color: '#ff6b9d',
    glowColor: '#ff8fb3',
    size: 'small',
    magical: true,
    description: 'A beautiful rose that glows softly in the evening'
  },
  {
    id: 'sunflower',
    name: 'Golden Sunflower',
    category: 'flower',
    color: '#ffd93d',
    glowColor: '#ffe066',
    size: 'medium',
    magical: true,
    description: 'A bright sunflower that radiates warm light'
  },
  {
    id: 'lavender',
    name: 'Peaceful Lavender',
    category: 'flower',
    color: '#b19cd9',
    size: 'small',
    magical: false,
    description: 'Calming lavender with a soothing fragrance'
  },
  {
    id: 'oak_tree',
    name: 'Wisdom Oak',
    category: 'tree',
    color: '#8b4513',
    glowColor: '#90EE90',
    size: 'large',
    magical: true,
    description: 'An ancient oak tree with mystical properties'
  },
  {
    id: 'cherry_tree',
    name: 'Cherry Blossom',
    category: 'tree',
    color: '#ffb7c5',
    size: 'medium',
    magical: false,
    description: 'A delicate cherry tree with pink blossoms'
  },
  {
    id: 'fairy_bush',
    name: 'Fairy Bush',
    category: 'magical',
    color: '#98fb98',
    glowColor: '#00ff7f',
    size: 'small',
    magical: true,
    description: 'A magical bush that attracts friendly fairies'
  },
  {
    id: 'crystal_flower',
    name: 'Crystal Bloom',
    category: 'magical',
    color: '#e6e6fa',
    glowColor: '#9370db',
    size: 'small',
    magical: true,
    description: 'A rare crystalline flower that shimmers with magic'
  },
  {
    id: 'moonlight_lily',
    name: 'Moonlight Lily',
    category: 'magical',
    color: '#f0f8ff',
    glowColor: '#87ceeb',
    size: 'medium',
    magical: true,
    description: 'A lily that glows with ethereal moonlight'
  }
];
