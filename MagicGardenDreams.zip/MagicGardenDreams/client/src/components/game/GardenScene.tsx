import { Canvas } from "@react-three/fiber";
import { OrbitControls, Sky, useTexture } from "@react-three/drei";
import { Suspense, useRef } from "react";
import * as THREE from "three";
import { useGarden } from "../../lib/stores/useGarden";
import { useAudio } from "../../lib/stores/useAudio";
import { PlantItem } from "./PlantItem";
import { MagicalEffects } from "./MagicalEffects";

function Terrain() {
  const grassTexture = useTexture("/textures/grass.png");
  const { selectedPlantType, addPlant, hoveredPosition, setHoveredPosition } = useGarden();
  const { playSuccess } = useAudio();
  
  // Configure texture
  grassTexture.wrapS = grassTexture.wrapT = THREE.RepeatWrapping;
  grassTexture.repeat.set(8, 8);

  const handleTerrainClick = (event: THREE.Event) => {
    if (!selectedPlantType) return;
    
    event.stopPropagation();
    const point = event.point;
    
    // Place plant at clicked position
    addPlant([point.x, 0, point.z]);
    playSuccess();
  };

  const handlePointerMove = (event: THREE.Event) => {
    if (selectedPlantType) {
      const point = event.point;
      setHoveredPosition([point.x, 0, point.z]);
    }
  };

  const handlePointerLeave = () => {
    setHoveredPosition(null);
  };

  return (
    <group>
      <mesh 
        rotation={[-Math.PI / 2, 0, 0]} 
        position={[0, 0, 0]}
        onClick={handleTerrainClick}
        onPointerMove={handlePointerMove}
        onPointerLeave={handlePointerLeave}
      >
        <planeGeometry args={[20, 20]} />
        <meshLambertMaterial map={grassTexture} />
      </mesh>
      
      {/* Planting preview */}
      {hoveredPosition && selectedPlantType && (
        <mesh position={hoveredPosition} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[0.3, 0.4]} />
          <meshBasicMaterial color="#90EE90" transparent opacity={0.6} />
        </mesh>
      )}
    </group>
  );
}

function Lighting() {
  return (
    <>
      <ambientLight intensity={0.4} color="#ffeaa7" />
      <directionalLight
        position={[10, 10, 5]}
        intensity={1}
        color="#fff"
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-camera-far={50}
        shadow-camera-left={-20}
        shadow-camera-right={20}
        shadow-camera-top={20}
        shadow-camera-bottom={-20}
      />
      <pointLight position={[0, 5, 0]} intensity={0.3} color="#e17055" />
    </>
  );
}

function Plants() {
  const { plants, removePlant } = useGarden();

  return (
    <>
      {plants.map((plant) => (
        <PlantItem
          key={plant.id}
          plant={plant}
          onClick={() => {
            if (window.confirm(`Remove ${plant.plantType.name}?`)) {
              removePlant(plant.id);
            }
          }}
        />
      ))}
    </>
  );
}

export function GardenScene() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  return (
    <div className="w-full h-full">
      <Canvas
        ref={canvasRef}
        shadows
        camera={{
          position: [0, 8, 12],
          fov: 50,
          near: 0.1,
          far: 1000
        }}
        gl={{
          antialias: true,
          powerPreference: "default"
        }}
      >
        <color attach="background" args={["#1a1a2e"]} />
        
        <Suspense fallback={null}>
          <Sky
            distance={450000}
            sunPosition={[5, 1, 8]}
            inclination={0.49}
            azimuth={0.25}
          />
          
          <Lighting />
          <Terrain />
          <Plants />
          <MagicalEffects />
          
          <OrbitControls
            enablePan={true}
            enableZoom={true}
            enableRotate={true}
            maxPolarAngle={Math.PI / 2.2}
            minDistance={5}
            maxDistance={25}
            target={[0, 0, 0]}
          />
        </Suspense>
      </Canvas>
    </div>
  );
}
