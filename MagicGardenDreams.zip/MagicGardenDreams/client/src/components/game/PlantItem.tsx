import { useRef, useState, useEffect } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { PlacedPlant } from "../../lib/gardenTypes";

interface PlantItemProps {
  plant: PlacedPlant;
  onClick?: () => void;
}

export function PlantItem({ plant, onClick }: PlantItemProps) {
  const meshRef = useRef<THREE.Group>(null);
  const [hovered, setHovered] = useState(false);
  const glowMaterialRef = useRef<THREE.MeshBasicMaterial>(null);

  // Animation for growth
  useFrame((state) => {
    if (!meshRef.current) return;

    // Gentle swaying animation
    meshRef.current.rotation.z = Math.sin(state.clock.elapsedTime * 0.5 + plant.position[0]) * 0.02;
    
    // Glow effect animation
    if (plant.isGlowing && glowMaterialRef.current) {
      const glowIntensity = 0.5 + Math.sin(state.clock.elapsedTime * 2) * 0.3;
      glowMaterialRef.current.opacity = glowIntensity;
    }

    // Growth animation
    const targetScale = plant.scale * plant.growthStage;
    const currentScale = meshRef.current.scale.x;
    if (currentScale < targetScale) {
      const newScale = THREE.MathUtils.lerp(currentScale, targetScale, 0.02);
      meshRef.current.scale.setScalar(newScale);
    }
  });

  useEffect(() => {
    document.body.style.cursor = hovered ? 'pointer' : 'auto';
    return () => {
      document.body.style.cursor = 'auto';
    };
  }, [hovered]);

  const renderPlantGeometry = () => {
    const { plantType } = plant;
    
    switch (plantType.category) {
      case 'flower':
        return (
          <group>
            {/* Stem */}
            <mesh position={[0, 0.3, 0]}>
              <cylinderGeometry args={[0.02, 0.02, 0.6]} />
              <meshLambertMaterial color="#2d5016" />
            </mesh>
            
            {/* Flower head */}
            <mesh position={[0, 0.7, 0]}>
              <sphereGeometry args={[0.15]} />
              <meshLambertMaterial color={plantType.color} />
            </mesh>
            
            {/* Petals */}
            {[0, 1, 2, 3, 4].map((i) => (
              <mesh
                key={i}
                position={[
                  Math.cos((i * Math.PI * 2) / 5) * 0.12,
                  0.7,
                  Math.sin((i * Math.PI * 2) / 5) * 0.12
                ]}
                rotation={[0, (i * Math.PI * 2) / 5, 0]}
              >
                <sphereGeometry args={[0.08]} />
                <meshLambertMaterial color={plantType.color} />
              </mesh>
            ))}

            {/* Magical glow effect */}
            {plant.isGlowing && (
              <mesh position={[0, 0.7, 0]}>
                <sphereGeometry args={[0.25]} />
                <meshBasicMaterial
                  ref={glowMaterialRef}
                  color={plantType.glowColor}
                  transparent
                  opacity={0.3}
                />
              </mesh>
            )}
          </group>
        );

      case 'tree':
        return (
          <group>
            {/* Trunk */}
            <mesh position={[0, 0.5, 0]}>
              <cylinderGeometry args={[0.1, 0.15, 1]} />
              <meshLambertMaterial color="#8b4513" />
            </mesh>
            
            {/* Canopy */}
            <mesh position={[0, 1.2, 0]}>
              <sphereGeometry args={[0.6]} />
              <meshLambertMaterial color={plantType.color} />
            </mesh>

            {/* Magical tree glow */}
            {plant.isGlowing && (
              <mesh position={[0, 1.2, 0]}>
                <sphereGeometry args={[0.8]} />
                <meshBasicMaterial
                  ref={glowMaterialRef}
                  color={plantType.glowColor}
                  transparent
                  opacity={0.2}
                />
              </mesh>
            )}
          </group>
        );

      case 'magical':
        return (
          <group>
            {/* Base crystal/magical form */}
            <mesh position={[0, 0.3, 0]}>
              <coneGeometry args={[0.2, 0.6]} />
              <meshLambertMaterial color={plantType.color} />
            </mesh>
            
            {/* Magical particles effect */}
            {[0, 1, 2].map((i) => (
              <mesh
                key={i}
                position={[
                  Math.cos(Date.now() * 0.001 + i) * 0.3,
                  0.6 + Math.sin(Date.now() * 0.002 + i) * 0.2,
                  Math.sin(Date.now() * 0.001 + i) * 0.3
                ]}
              >
                <sphereGeometry args={[0.03]} />
                <meshBasicMaterial color={plantType.glowColor} />
              </mesh>
            ))}

            {/* Strong magical glow */}
            <mesh position={[0, 0.3, 0]}>
              <sphereGeometry args={[0.4]} />
              <meshBasicMaterial
                ref={glowMaterialRef}
                color={plantType.glowColor}
                transparent
                opacity={0.4}
              />
            </mesh>
          </group>
        );

      default:
        return (
          <mesh>
            <boxGeometry args={[0.2, 0.2, 0.2]} />
            <meshLambertMaterial color={plantType.color} />
          </mesh>
        );
    }
  };

  return (
    <group
      ref={meshRef}
      position={plant.position}
      rotation={[0, plant.rotation, 0]}
      onPointerOver={() => setHovered(true)}
      onPointerOut={() => setHovered(false)}
      onClick={onClick}
    >
      {renderPlantGeometry()}
      
      {/* Hover indicator */}
      {hovered && (
        <mesh position={[0, -0.05, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[0.3, 0.35]} />
          <meshBasicMaterial color="#ffffff" transparent opacity={0.8} />
        </mesh>
      )}
    </group>
  );
}
