import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useGarden } from "../../lib/stores/useGarden";
import { useAudio } from "../../lib/stores/useAudio";
import { 
  Save, 
  FolderOpen, 
  Trash2, 
  VolumeX, 
  Volume2, 
  Sparkles, 
  Flower2,
  Settings
} from "lucide-react";
import { useState } from "react";

export function GardenUI() {
  const { 
    gardenName, 
    plants, 
    selectedPlantType,
    setGardenName, 
    saveGarden, 
    loadGarden, 
    clearGarden 
  } = useGarden();
  
  const { isMuted, toggleMute } = useAudio();
  const [showSettings, setShowSettings] = useState(false);

  const magicalPlantCount = plants.filter(p => p.plantType.magical).length;
  const totalPlants = plants.length;

  return (
    <>
      {/* Top Bar */}
      <div className="fixed top-4 left-1/2 transform -translate-x-1/2 z-10">
        <Card className="bg-black/80 border-green-600/30">
          <CardContent className="p-4">
            <div className="flex items-center gap-4">
              <Input
                value={gardenName}
                onChange={(e) => setGardenName(e.target.value)}
                className="text-lg font-semibold bg-transparent border-none text-white text-center min-w-48"
                placeholder="Garden Name"
              />
              
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="bg-green-600/20 text-green-300 border-green-400/30">
                  <Flower2 className="w-3 h-3 mr-1" />
                  {totalPlants} Plants
                </Badge>
                
                {magicalPlantCount > 0 && (
                  <Badge variant="secondary" className="bg-purple-600/20 text-purple-300 border-purple-400/30">
                    <Sparkles className="w-3 h-3 mr-1" />
                    {magicalPlantCount} Magical
                  </Badge>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Controls */}
      <div className="fixed top-4 right-4 z-10">
        <Card className="bg-black/80 border-green-600/30">
          <CardContent className="p-3">
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleMute}
                className="text-white hover:bg-gray-700/50"
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowSettings(!showSettings)}
                className="text-white hover:bg-gray-700/50"
              >
                <Settings className="w-4 h-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Settings Panel */}
      {showSettings && (
        <div className="fixed top-16 right-4 z-10">
          <Card className="w-64 bg-black/90 border-green-600/30">
            <CardContent className="p-4">
              <h3 className="text-lg font-semibold text-white mb-4">Garden Controls</h3>
              
              <div className="space-y-3">
                <Button
                  onClick={saveGarden}
                  className="w-full bg-green-600 hover:bg-green-700 text-white"
                >
                  <Save className="w-4 h-4 mr-2" />
                  Save Garden
                </Button>
                
                <Button
                  onClick={loadGarden}
                  variant="outline"
                  className="w-full border-gray-600 text-white hover:bg-gray-700/50"
                >
                  <FolderOpen className="w-4 h-4 mr-2" />
                  Load Garden
                </Button>
                
                <Button
                  onClick={() => {
                    if (confirm('Are you sure you want to clear your garden? This cannot be undone.')) {
                      clearGarden();
                    }
                  }}
                  variant="destructive"
                  className="w-full"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Clear Garden
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Instructions */}
      {selectedPlantType && (
        <div className="fixed bottom-4 left-1/2 transform -translate-x-1/2 z-10">
          <Card className="bg-green-900/80 border-green-600/50">
            <CardContent className="p-3">
              <p className="text-green-100 text-sm font-medium text-center">
                Click anywhere in the garden to plant your selected flower! 🌸
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Welcome Message */}
      {totalPlants === 0 && !selectedPlantType && (
        <div className="fixed bottom-4 left-1/2 transform -translate-x-1/2 z-10">
          <Card className="bg-blue-900/80 border-blue-600/50">
            <CardContent className="p-4">
              <div className="text-center">
                <h3 className="text-lg font-semibold text-blue-100 mb-2">
                  Welcome to Your Magical Garden! ✨
                </h3>
                <p className="text-blue-200 text-sm leading-relaxed">
                  Select a plant from the palette on the left to start creating your dream garden.
                  <br />
                  Magical plants will glow and create beautiful effects!
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </>
  );
}
