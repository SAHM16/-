import { useRef, useMemo } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

export function MagicalEffects() {
  const particlesRef = useRef<THREE.Points>(null);
  const sparklesRef = useRef<THREE.Points>(null);

  // Create floating magical particles
  const particleGeometry = useMemo(() => {
    const geometry = new THREE.BufferGeometry();
    const particleCount = 50;
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount; i++) {
      // Random positions in a large area
      positions[i * 3] = (Math.random() - 0.5) * 20;
      positions[i * 3 + 1] = Math.random() * 3 + 1;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 20;

      // Magical colors
      const color = new THREE.Color();
      color.setHSL(Math.random() * 0.3 + 0.6, 0.8, 0.7); // Purple to blue range
      colors[i * 3] = color.r;
      colors[i * 3 + 1] = color.g;
      colors[i * 3 + 2] = color.b;
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    return geometry;
  }, []);

  // Create sparkle effects
  const sparkleGeometry = useMemo(() => {
    const geometry = new THREE.BufferGeometry();
    const sparkleCount = 30;
    const positions = new Float32Array(sparkleCount * 3);
    const colors = new Float32Array(sparkleCount * 3);

    for (let i = 0; i < sparkleCount; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 15;
      positions[i * 3 + 1] = Math.random() * 2 + 0.5;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 15;

      // Bright sparkle colors
      const color = new THREE.Color();
      color.setHSL(Math.random(), 0.9, 0.9);
      colors[i * 3] = color.r;
      colors[i * 3 + 1] = color.g;
      colors[i * 3 + 2] = color.b;
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    return geometry;
  }, []);

  useFrame((state) => {
    if (particlesRef.current) {
      // Gentle floating motion for particles
      const positions = particlesRef.current.geometry.attributes.position.array as Float32Array;
      for (let i = 0; i < positions.length; i += 3) {
        positions[i + 1] += Math.sin(state.clock.elapsedTime + positions[i]) * 0.001;
        
        // Reset particles that float too high
        if (positions[i + 1] > 4) {
          positions[i + 1] = 0.5;
        }
      }
      particlesRef.current.geometry.attributes.position.needsUpdate = true;
    }

    if (sparklesRef.current) {
      // Twinkling effect for sparkles
      sparklesRef.current.rotation.y = state.clock.elapsedTime * 0.1;
      
      const positions = sparklesRef.current.geometry.attributes.position.array as Float32Array;
      for (let i = 0; i < positions.length; i += 3) {
        positions[i + 1] += Math.sin(state.clock.elapsedTime * 2 + positions[i] * 10) * 0.002;
      }
      sparklesRef.current.geometry.attributes.position.needsUpdate = true;
    }
  });

  return (
    <group>
      {/* Floating magical particles */}
      <points ref={particlesRef} geometry={particleGeometry}>
        <pointsMaterial
          size={0.05}
          vertexColors
          transparent
          opacity={0.7}
          sizeAttenuation
        />
      </points>

      {/* Twinkling sparkles */}
      <points ref={sparklesRef} geometry={sparkleGeometry}>
        <pointsMaterial
          size={0.03}
          vertexColors
          transparent
          opacity={0.9}
          sizeAttenuation
        />
      </points>

      {/* Ambient magical glow */}
      <mesh position={[0, 2, 0]}>
        <sphereGeometry args={[10]} />
        <meshBasicMaterial
          color="#e6e6fa"
          transparent
          opacity={0.05}
          side={THREE.BackSide}
        />
      </mesh>
    </group>
  );
}
