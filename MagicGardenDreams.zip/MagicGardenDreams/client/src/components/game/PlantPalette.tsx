import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useGarden } from "../../lib/stores/useGarden";
import { PLANT_TYPES } from "../../lib/gardenTypes";
import { Sparkles, Flower, TreePine } from "lucide-react";

export function PlantPalette() {
  const { selectedPlantType, setSelectedPlantType } = useGarden();

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'flower': return <Flower className="w-4 h-4" />;
      case 'tree': return <TreePine className="w-4 h-4" />;
      case 'magical': return <Sparkles className="w-4 h-4" />;
      default: return <Flower className="w-4 h-4" />;
    }
  };

  return (
    <div className="fixed left-4 top-1/2 transform -translate-y-1/2 z-10">
      <Card className="w-72 max-h-96 overflow-y-auto bg-black/80 border-green-600/30">
        <CardContent className="p-4">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-green-400" />
            Plant Selection
          </h3>
          
          <div className="space-y-2">
            {PLANT_TYPES.map((plant) => (
              <Button
                key={plant.id}
                variant={selectedPlantType === plant.id ? "default" : "outline"}
                className={`w-full justify-start h-auto p-3 ${
                  selectedPlantType === plant.id 
                    ? "bg-green-600 hover:bg-green-700 text-white border-green-400" 
                    : "bg-gray-800/50 hover:bg-gray-700/50 text-white border-gray-600"
                }`}
                onClick={() => setSelectedPlantType(
                  selectedPlantType === plant.id ? null : plant.id
                )}
              >
                <div className="flex items-start gap-3 w-full">
                  <div 
                    className="w-8 h-8 rounded-full border-2 flex-shrink-0 flex items-center justify-center"
                    style={{ 
                      backgroundColor: plant.color + '40',
                      borderColor: plant.color 
                    }}
                  >
                    {getCategoryIcon(plant.category)}
                  </div>
                  
                  <div className="flex-1 text-left">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium text-sm">{plant.name}</span>
                      {plant.magical && (
                        <Badge variant="secondary" className="text-xs bg-purple-600/20 text-purple-300 border-purple-400/30">
                          <Sparkles className="w-3 h-3 mr-1" />
                          Magical
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-gray-300 leading-tight">
                      {plant.description}
                    </p>
                  </div>
                </div>
              </Button>
            ))}
          </div>
          
          <div className="mt-4 p-3 bg-blue-900/20 rounded-lg border border-blue-600/30">
            <p className="text-xs text-blue-200 leading-relaxed">
              💡 <strong>Tip:</strong> Select a plant and click anywhere in the garden to place it. 
              Magical plants glow and create special effects!
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
