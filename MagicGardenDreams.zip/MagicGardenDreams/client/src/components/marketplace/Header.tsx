import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Search, 
  Plus, 
  Heart, 
  MessageCircle, 
  User,
  Menu,
  Recycle,
  Bell,
  Settings
} from "lucide-react";
import { useMarketplace } from "../../lib/stores/useMarketplace";

export function Header() {
  const { 
    searchQuery, 
    setSearchQuery, 
    currentUser,
    favorites 
  } = useMarketplace();
  
  const [showMobileMenu, setShowMobileMenu] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full bg-gradient-to-r from-emerald-600 via-green-600 to-teal-600 shadow-lg">
      <div className="container flex h-20 items-center justify-between px-6">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <Recycle className="h-10 w-10 text-white animate-pulse" />
            <div className="absolute -top-1 -right-1 w-4 h-4 bg-yellow-400 rounded-full animate-bounce"></div>
          </div>
          <div className="flex flex-col">
            <h1 className="text-2xl font-bold text-white tracking-wide">خردة</h1>
            <span className="text-sm text-green-100 font-medium">سوق الأشياء المستعملة</span>
          </div>
        </div>

        {/* Search Bar - Desktop */}
        <div className="hidden md:flex flex-1 max-w-lg mx-6">
          <div className="relative w-full">
            <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <Input
              placeholder="ابحث عن أي شيء تريد شراءه أو بيعه..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="h-12 pr-12 pl-4 rounded-full bg-white/90 backdrop-blur border-0 shadow-lg focus:shadow-xl transition-all placeholder:text-gray-500 text-gray-800"
            />
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-3">
          {currentUser ? (
            <>
              {/* Add Item Button */}
              <Button 
                size="lg" 
                className="hidden sm:flex bg-white/20 hover:bg-white/30 text-white border border-white/30 backdrop-blur rounded-full px-6 font-medium"
              >
                <Plus className="h-5 w-5 ml-2" />
                أضف إعلان
              </Button>
              
              {/* Notifications */}
              <Button variant="ghost" size="lg" className="relative text-white hover:bg-white/20 rounded-full p-3">
                <Bell className="h-6 w-6" />
                <Badge 
                  className="absolute -top-1 -left-1 h-5 w-5 rounded-full p-0 text-xs bg-red-500 hover:bg-red-600 border-2 border-white"
                >
                  3
                </Badge>
              </Button>
              
              {/* Favorites */}
              <Button variant="ghost" size="lg" className="relative text-white hover:bg-white/20 rounded-full p-3">
                <Heart className="h-6 w-6" />
                {favorites.length > 0 && (
                  <Badge 
                    className="absolute -top-1 -left-1 h-5 w-5 rounded-full p-0 text-xs bg-pink-500 hover:bg-pink-600 border-2 border-white"
                  >
                    {favorites.length}
                  </Badge>
                )}
              </Button>
              
              {/* Messages */}
              <Button variant="ghost" size="lg" className="relative text-white hover:bg-white/20 rounded-full p-3">
                <MessageCircle className="h-6 w-6" />
                <Badge 
                  className="absolute -top-1 -left-1 h-5 w-5 rounded-full p-0 text-xs bg-blue-500 hover:bg-blue-600 border-2 border-white"
                >
                  5
                </Badge>
              </Button>
              
              {/* User Profile */}
              <div className="flex items-center gap-3 bg-white/20 rounded-full p-2 pr-4">
                <Avatar className="h-10 w-10 cursor-pointer border-2 border-white/50">
                  <AvatarImage src={currentUser.avatar} />
                  <AvatarFallback className="bg-gradient-to-br from-purple-500 to-pink-500 text-white font-bold">
                    {currentUser.fullName.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <span className="text-white font-medium hidden lg:block">{currentUser.fullName}</span>
              </div>
            </>
          ) : (
            <>
              <Button variant="ghost" size="lg" className="text-white hover:bg-white/20 rounded-full px-6">
                تسجيل الدخول
              </Button>
              <Button size="lg" className="bg-white text-green-600 hover:bg-gray-100 rounded-full px-6 font-bold">
                إنشاء حساب
              </Button>
            </>
          )}
          
          {/* Mobile Menu */}
          <Button 
            variant="ghost" 
            size="sm" 
            className="md:hidden"
            onClick={() => setShowMobileMenu(!showMobileMenu)}
          >
            <Menu className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Mobile Search */}
      <div className="md:hidden px-6 py-4 bg-gradient-to-r from-emerald-500 to-teal-500">
        <div className="relative">
          <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
          <Input
            placeholder="ابحث عن أي شيء تريد شراءه أو بيعه..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="h-12 pr-12 pl-4 rounded-full bg-white/90 backdrop-blur border-0 shadow-lg placeholder:text-gray-500 text-gray-800"
          />
        </div>
      </div>

      {/* Mobile Menu */}
      {showMobileMenu && (
        <div className="md:hidden bg-white shadow-xl border-t">
          <div className="p-6 space-y-4">
            <Button className="w-full justify-start h-14 rounded-xl bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white shadow-lg">
              <Plus className="h-5 w-5 ml-3" />
              <span className="font-medium">أضف إعلان جديد</span>
            </Button>
            
            <div className="grid grid-cols-2 gap-3">
              <Button variant="ghost" className="h-12 rounded-xl border border-gray-200 hover:bg-pink-50">
                <Heart className="h-5 w-5 ml-2 text-pink-500" />
                <span>المفضلة ({favorites.length})</span>
              </Button>
              
              <Button variant="ghost" className="h-12 rounded-xl border border-gray-200 hover:bg-blue-50">
                <MessageCircle className="h-5 w-5 ml-2 text-blue-500" />
                <span>الرسائل (5)</span>
              </Button>
              
              <Button variant="ghost" className="h-12 rounded-xl border border-gray-200 hover:bg-purple-50">
                <Bell className="h-5 w-5 ml-2 text-purple-500" />
                <span>التنبيهات (3)</span>
              </Button>
              
              <Button variant="ghost" className="h-12 rounded-xl border border-gray-200 hover:bg-gray-50">
                <User className="h-5 w-5 ml-2 text-gray-500" />
                <span>الملف الشخصي</span>
              </Button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}