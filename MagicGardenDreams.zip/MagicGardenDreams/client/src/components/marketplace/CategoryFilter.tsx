import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Smartphone, 
  Sofa, 
  Shirt, 
  Book, 
  Wrench, 
  Bike, 
  Home, 
  Car, 
  Package,
  Grid3X3
} from "lucide-react";
import { useMarketplace } from "../../lib/stores/useMarketplace";

const iconMap = {
  Smartphone,
  Sofa,
  Shirt,
  Book,
  Wrench,
  Bike,
  Home,
  Car,
  Package
};

export function CategoryFilter() {
  const { 
    categories, 
    selectedCategory, 
    setSelectedCategory, 
    items 
  } = useMarketplace();

  const getItemCountForCategory = (categoryId: string) => {
    return items.filter(item => item.category === categoryId && item.status === 'active').length;
  };

  const totalActiveItems = items.filter(item => item.status === 'active').length;

  return (
    <Card className="sticky top-32 bg-white shadow-lg border-0 rounded-2xl overflow-hidden">
      <CardContent className="p-6">
        <h3 className="font-bold text-xl mb-6 flex items-center gap-3 text-gray-800">
          <div className="p-2 bg-gradient-to-br from-blue-500 to-purple-500 rounded-xl">
            <Grid3X3 className="h-5 w-5 text-white" />
          </div>
          تصفح الفئات
        </h3>
        
        <div className="space-y-3">
          {/* All Categories */}
          <Button
            variant={selectedCategory === null ? "default" : "ghost"}
            className={`w-full justify-between h-auto p-4 rounded-xl transition-all duration-200 ${
              selectedCategory === null 
                ? "bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600 text-white shadow-lg" 
                : "hover:bg-gray-50 text-gray-700 border border-gray-200"
            }`}
            onClick={() => setSelectedCategory(null)}
          >
            <div className="flex items-center gap-3">
              <Grid3X3 className="h-5 w-5" />
              <span className="font-medium">جميع الفئات</span>
            </div>
            <Badge 
              variant="secondary" 
              className={`text-sm px-3 py-1 rounded-full font-bold ${
                selectedCategory === null 
                  ? "bg-white/20 text-white border-0" 
                  : "bg-emerald-100 text-emerald-700"
              }`}
            >
              {totalActiveItems}
            </Badge>
          </Button>

          {/* Individual Categories */}
          {categories.map((category) => {
            const IconComponent = iconMap[category.icon as keyof typeof iconMap];
            const itemCount = getItemCountForCategory(category.id);
            const isSelected = selectedCategory === category.id;
            
            return (
              <Button
                key={category.id}
                variant="ghost"
                className={`w-full justify-between h-auto p-4 rounded-xl transition-all duration-200 ${
                  isSelected 
                    ? "bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white shadow-lg" 
                    : "hover:bg-gray-50 text-gray-700 border border-gray-200"
                }`}
                onClick={() => setSelectedCategory(
                  selectedCategory === category.id ? null : category.id
                )}
              >
                <div className="flex items-center gap-3">
                  {IconComponent && (
                    <div className={`p-2 rounded-lg ${
                      isSelected ? "bg-white/20" : "bg-gray-100"
                    }`}>
                      <IconComponent className={`h-4 w-4 ${
                        isSelected ? "text-white" : "text-gray-600"
                      }`} />
                    </div>
                  )}
                  <div className="text-right">
                    <div className="font-semibold text-sm">{category.nameAr}</div>
                    <div className={`text-xs ${
                      isSelected ? "text-white/80" : "text-gray-500"
                    }`}>
                      {category.name}
                    </div>
                  </div>
                </div>
                {itemCount > 0 && (
                  <Badge 
                    variant="secondary" 
                    className={`text-sm px-3 py-1 rounded-full font-bold ${
                      isSelected 
                        ? "bg-white/20 text-white border-0" 
                        : "bg-blue-100 text-blue-700"
                    }`}
                  >
                    {itemCount}
                  </Badge>
                )}
              </Button>
            );
          })}
        </div>
        
        {selectedCategory && (
          <div className="mt-6 pt-6 border-t border-gray-200">
            <Button
              variant="outline"
              size="sm"
              className="w-full h-12 rounded-xl border-2 border-gray-300 hover:bg-red-50 hover:border-red-300 text-gray-700 hover:text-red-600 font-medium transition-all"
              onClick={() => setSelectedCategory(null)}
            >
              ✕ إزالة التصفية
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}