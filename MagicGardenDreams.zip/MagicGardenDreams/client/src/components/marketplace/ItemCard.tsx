import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Heart, 
  MessageCircle, 
  MapPin, 
  Eye,
  Clock,
  Star
} from "lucide-react";
import { Item, useMarketplace } from "../../lib/stores/useMarketplace";

interface ItemCardProps {
  item: Item;
  onItemClick?: (item: Item) => void;
}

export function ItemCard({ item, onItemClick }: ItemCardProps) {
  const { favorites, addToFavorites, removeFromFavorites } = useMarketplace();
  const [imageLoaded, setImageLoaded] = useState(false);
  
  const isFavorite = favorites.includes(item.id);
  const primaryImage = item.images[0] || '/placeholder-image.jpg';

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isFavorite) {
      removeFromFavorites(item.id);
    } else {
      addToFavorites(item.id);
    }
  };

  const handleMessageClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    // Handle opening chat with seller
    console.log('Open chat with seller:', item.seller.id);
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'منذ قليل';
    if (diffInHours < 24) return `منذ ${diffInHours} ساعة`;
    
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 7) return `منذ ${diffInDays} يوم`;
    
    const diffInWeeks = Math.floor(diffInDays / 7);
    return `منذ ${diffInWeeks} أسبوع`;
  };

  const getConditionText = (condition: string) => {
    const conditionMap = {
      excellent: 'ممتاز',
      good: 'جيد',
      fair: 'مقبول',
      poor: 'سيء'
    };
    return conditionMap[condition as keyof typeof conditionMap] || condition;
  };

  const getConditionColor = (condition: string) => {
    const colorMap = {
      excellent: 'bg-green-100 text-green-800',
      good: 'bg-blue-100 text-blue-800',
      fair: 'bg-yellow-100 text-yellow-800',
      poor: 'bg-red-100 text-red-800'
    };
    return colorMap[condition as keyof typeof colorMap] || 'bg-gray-100 text-gray-800';
  };

  return (
    <Card 
      className="group cursor-pointer hover:shadow-2xl hover:scale-[1.02] transition-all duration-300 overflow-hidden rounded-2xl border-0 bg-white shadow-lg"
      onClick={() => onItemClick?.(item)}
    >
      <div className="relative">
        <div className="aspect-[4/3] bg-gradient-to-br from-gray-100 to-gray-200 overflow-hidden rounded-t-2xl">
          <img
            src={primaryImage}
            alt={item.title}
            className={`w-full h-full object-cover transition-all duration-500 group-hover:scale-110 ${
              imageLoaded ? 'opacity-100' : 'opacity-0'
            }`}
            onLoad={() => setImageLoaded(true)}
            onError={(e) => {
              const target = e.target as HTMLImageElement;
              target.src = '/placeholder-image.jpg';
              setImageLoaded(true);
            }}
          />
          {!imageLoaded && (
            <div className="absolute inset-0 bg-gradient-to-br from-gray-200 to-gray-300 animate-pulse" />
          )}
          
          {/* Overlay gradient */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        </div>

        {/* Price Badge */}
        <div className="absolute top-3 left-3">
          {item.isFree ? (
            <Badge className="bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white border-0 shadow-lg px-3 py-1 text-sm font-bold rounded-full">
              🎁 مجاني
            </Badge>
          ) : (
            <Badge className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white border-0 shadow-lg px-3 py-1 text-sm font-bold rounded-full">
              {item.price.toLocaleString('ar-SA')} ر.س
            </Badge>
          )}
        </div>

        {/* Favorite Button */}
        <Button
          variant="ghost"
          size="sm"
          className={`absolute top-3 right-3 p-2.5 rounded-full shadow-lg backdrop-blur transition-all duration-300 ${
            isFavorite 
              ? 'bg-pink-500 text-white hover:bg-pink-600 scale-110' 
              : 'bg-white/90 text-gray-600 hover:bg-white hover:scale-110'
          }`}
          onClick={handleFavoriteClick}
        >
          <Heart className={`h-4 w-4 ${isFavorite ? 'fill-current' : ''}`} />
        </Button>

        {/* Status Badge */}
        {item.status !== 'active' && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
            <Badge variant="destructive" className="text-lg px-4 py-2">
              {item.status === 'sold' ? 'مباع' : 'محجوز'}
            </Badge>
          </div>
        )}
      </div>

      <CardContent className="p-5">
        <div className="space-y-4">
          {/* Title and Description */}
          <div>
            <h3 className="font-bold text-lg text-gray-800 line-clamp-2 text-right leading-tight">
              {item.title}
            </h3>
            <p className="text-sm text-gray-600 line-clamp-2 text-right mt-2 leading-relaxed">
              {item.description}
            </p>
          </div>

          {/* Condition */}
          <div className="flex justify-end">
            <Badge 
              className={`text-xs font-medium px-3 py-1 rounded-full border-0 ${getConditionColor(item.condition)}`}
            >
              الحالة: {getConditionText(item.condition)}
            </Badge>
          </div>

          {/* Seller Info */}
          <div className="flex items-center justify-between bg-gray-50 rounded-xl p-3">
            <div className="flex items-center gap-3">
              <Avatar className="h-8 w-8 border-2 border-white shadow-sm">
                <AvatarImage src={item.seller.avatar} />
                <AvatarFallback className="text-sm font-medium bg-gradient-to-br from-blue-500 to-purple-500 text-white">
                  {item.seller.fullName.charAt(0)}
                </AvatarFallback>
              </Avatar>
              <div>
                <span className="text-sm font-medium text-gray-800">
                  {item.seller.fullName}
                </span>
                <div className="flex items-center gap-1 mt-0.5">
                  <Star className="h-3 w-3 text-yellow-400 fill-current" />
                  <span className="text-xs text-gray-500">4.8</span>
                </div>
              </div>
            </div>
            
            <Button
              variant="outline"
              size="sm"
              className="h-9 px-4 rounded-full bg-white border-gray-200 hover:bg-blue-50 hover:border-blue-300 transition-all"
              onClick={handleMessageClick}
            >
              <MessageCircle className="h-4 w-4 ml-1 text-blue-500" />
              <span className="text-blue-600 font-medium">رسالة</span>
            </Button>
          </div>

          {/* Location and Time */}
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-1.5 bg-green-50 px-3 py-1.5 rounded-full">
              <MapPin className="h-3.5 w-3.5 text-green-600" />
              <span className="text-green-700 font-medium">{item.location}</span>
            </div>
            
            <div className="flex items-center gap-4 text-gray-500">
              <div className="flex items-center gap-1">
                <Eye className="h-3.5 w-3.5" />
                <span>{item.views}</span>
              </div>
              <div className="flex items-center gap-1">
                <Clock className="h-3.5 w-3.5" />
                <span>{formatTimeAgo(item.createdAt)}</span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}