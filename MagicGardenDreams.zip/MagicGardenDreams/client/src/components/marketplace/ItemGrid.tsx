import { useMemo } from "react";
import { ItemCard } from "./ItemCard";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Package, 
  Search,
  Filter,
  SortAsc
} from "lucide-react";
import { Item, useMarketplace } from "../../lib/stores/useMarketplace";

interface ItemGridProps {
  onItemClick?: (item: Item) => void;
}

export function ItemGrid({ onItemClick }: ItemGridProps) {
  const { 
    items, 
    selectedCategory, 
    searchQuery,
    isLoading 
  } = useMarketplace();

  const filteredItems = useMemo(() => {
    let filtered = items.filter(item => item.status === 'active');

    // Filter by category
    if (selectedCategory) {
      filtered = filtered.filter(item => item.category === selectedCategory);
    }

    // Filter by search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(item => 
        item.title.toLowerCase().includes(query) ||
        item.description.toLowerCase().includes(query) ||
        item.location.toLowerCase().includes(query)
      );
    }

    // Sort by newest first
    return filtered.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }, [items, selectedCategory, searchQuery]);

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {Array.from({ length: 8 }).map((_, index) => (
          <Card key={index} className="overflow-hidden">
            <div className="aspect-[4/3] bg-gray-200 animate-pulse" />
            <CardContent className="p-4 space-y-3">
              <div className="h-4 bg-gray-200 rounded animate-pulse" />
              <div className="h-3 bg-gray-200 rounded animate-pulse w-3/4" />
              <div className="flex justify-between items-center">
                <div className="h-6 bg-gray-200 rounded animate-pulse w-16" />
                <div className="h-8 bg-gray-200 rounded animate-pulse w-20" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (filteredItems.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <div className="mb-6">
          {searchQuery ? (
            <Search className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          ) : (
            <Package className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          )}
        </div>
        
        <h3 className="text-xl font-semibold mb-2">
          {searchQuery ? 'لا توجد نتائج' : 'لا توجد عناصر'}
        </h3>
        
        <p className="text-muted-foreground mb-6 max-w-md">
          {searchQuery 
            ? `لم نجد أي عناصر تطابق البحث "${searchQuery}"`
            : selectedCategory 
              ? 'لا توجد عناصر في هذه الفئة حالياً'
              : 'لا توجد عناصر متاحة حالياً'
          }
        </p>

        <div className="flex gap-3">
          {searchQuery && (
            <Button 
              variant="outline"
              onClick={() => useMarketplace.getState().setSearchQuery('')}
            >
              مسح البحث
            </Button>
          )}
          
          {selectedCategory && (
            <Button 
              variant="outline"
              onClick={() => useMarketplace.getState().setSelectedCategory(null)}
            >
              عرض جميع الفئات
            </Button>
          )}
          
          <Button>
            أضف إعلان جديد
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Results Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <h2 className="text-lg font-semibold">
            {filteredItems.length} عنصر
            {searchQuery && (
              <span className="text-muted-foreground mr-2">
                لـ "{searchQuery}"
              </span>
            )}
          </h2>
        </div>
        
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Filter className="h-4 w-4 mr-2" />
            تصفية
          </Button>
          <Button variant="outline" size="sm">
            <SortAsc className="h-4 w-4 mr-2" />
            ترتيب
          </Button>
        </div>
      </div>

      {/* Items Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredItems.map((item) => (
          <ItemCard 
            key={item.id} 
            item={item} 
            onItemClick={onItemClick}
          />
        ))}
      </div>

      {/* Load More */}
      {filteredItems.length >= 20 && (
        <div className="flex justify-center pt-8">
          <Button variant="outline" size="lg">
            عرض المزيد
          </Button>
        </div>
      )}
    </div>
  );
}