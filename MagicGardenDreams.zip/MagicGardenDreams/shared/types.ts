export interface User {
  id: number;
  username: string;
  email: string;
  fullName: string;
  phone?: string;
  location?: string;
  avatar?: string;
  createdAt: Date;
}

export interface Category {
  id: string;
  name: string;
  nameAr: string;
  icon: string;
}

export interface Item {
  id: string;
  title: string;
  description: string;
  price: number;
  isFree: boolean;
  category: string;
  condition: 'excellent' | 'good' | 'fair' | 'poor';
  images: string[];
  sellerId: number;
  seller: User;
  location: string;
  status: 'active' | 'sold' | 'reserved';
  createdAt: Date;
  updatedAt: Date;
  views: number;
}

export interface Message {
  id: string;
  senderId: number;
  receiverId: number;
  itemId: string;
  content: string;
  createdAt: Date;
  read: boolean;
}

export interface Favorite {
  id: string;
  userId: number;
  itemId: string;
  createdAt: Date;
}

export const CATEGORIES: Category[] = [
  { id: 'electronics', name: 'Electronics', nameAr: 'إلكترونيات', icon: 'Smartphone' },
  { id: 'furniture', name: 'Furniture', nameAr: 'أثاث', icon: 'Sofa' },
  { id: 'clothing', name: 'Clothing', nameAr: 'ملابس', icon: 'Shirt' },
  { id: 'books', name: 'Books', nameAr: 'كتب', icon: 'Book' },
  { id: 'tools', name: 'Tools', nameAr: 'أدوات', icon: 'Wrench' },
  { id: 'sports', name: 'Sports & Outdoors', nameAr: 'رياضة وخارجية', icon: 'Bike' },
  { id: 'home', name: 'Home & Garden', nameAr: 'بيت وحديقة', icon: 'Home' },
  { id: 'vehicles', name: 'Vehicles', nameAr: 'مركبات', icon: 'Car' },
  { id: 'other', name: 'Other', nameAr: 'أخرى', icon: 'Package' }
];